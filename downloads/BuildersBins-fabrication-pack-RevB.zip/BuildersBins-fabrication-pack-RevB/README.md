# BuildersBins station, Rev B: fabrication pack

20 November 2026 · Recycle Group · questions: toby@recycle.au

This is a concept design for quotation. Please use it to prepare shop drawings and a price. Nothing should be cut until the shop drawings have been approved and the engineer has certified the design.

## What's in the pack

| Folder / file | What it is |
|---|---|
| `BuildersBins-fabrication-drawings-RevB.pdf` | 16 A3 sheets:<br>• general arrangement<br>• hook skid<br>• kerb rail details<br>• one dimensioned sheet per bin width<br>• flat patterns<br>• cut list |
| `STEP/` | 3D CAD (AP214, mm), one file each for:<br>• the skid<br>• each bin width (1, 2, 3, 4 and 6 modules)<br>• the full station in its default layout |
| `DXF/` | 59 laser-cut flats in mm (`$INSUNITS=4`), one file per part.<br>Layers: `CUT` (profile), `BEND` (dashed bend lines with direction) and `TEXT` (part code, thickness, quantity).<br>File names give the part code, thickness and quantity per item. |
| `BuildersBins-cut-list-RevB.xlsx` | Plates, sections, hardware and masses, per item and per station |
| `BuildersBins-fabricator-spec-RevB.pdf` | The written specification: requirements, locks, lights, alarm and finishes |
| `renders/` | Reference images |

## The kerb rail (the "lip")

The old folded-plate lip has been replaced with a **100 × 50 × 6 RHS kerb (C350)**, stood 100 high.

- **Where:** along both outer edges and down the centre, for the full 5,850 bin zone.
- **Ends:** the rails butt into full-width RHS stops at the rear and hook ends. They are welded all round, and the stop ends are capped with 6 mm plate.
- **Weld:** 6 mm continuous fillet, both sides, full length, onto the 10 mm deck over SHS 89 cross members.
- **Clearance:** bins sit 5 mm clear of each rail. They drop in without binding and can't move more than 5 mm across.
- **Fork clearance:** fork pockets sit 100 above the rail top, so the forks never touch the rail.
- **Buffers:** 10 mm rubber buffers on each bin side wall fill the 20 mm gaps, so each row packs tight between the stops and can't slide.

## Key dimensions

**Skid**
- 6,300 × 2,450 overall, 1,999 to the ridge
- Deck top 99: SHS 89 runners and cross members plus a 10 mm deck. The spec page rounds this to 100.
- Rail top 199

**Bins**
- 1,140 deep. Width = modules × 585 − 20, giving 565 / 1,150 / 1,735 / 2,320 / 3,490.
- Bin heights from the bin base:
  - lid front edge 1,800, back 1,900
  - flap hinge 1,100, flap top 1,766
  - fork pocket underside 200, pocket internal 200 × 100
  - floor top 310
- Trap door opening 990 × 1,300 in the right-hand side wall. The 1,030 × 1,340 leaf is top-hinged and laps 20 all round.

**Plate thicknesses**
- 4 mm: walls, floor, lid, flap and door
- 6 mm: pocket boxes, pocket-mouth frames and end caps
- 10 mm: deck
- 12 mm: roller brackets
- 20 mm: hook gussets

## Steel tare from the CAD

Steel only. Excludes welds, paint, hardware and electrics.

| Item | Each | Per station |
|---|---|---|
| Bin 1M (×3) | 334 kg | 1,001 kg |
| Bin 2M (×2) | 444 kg | 888 kg |
| Bin 3M (×1) | 555 kg | 555 kg |
| Bin 4M (×1) | 666 kg | 666 kg |
| Bin 6M (×1) | 887 kg | 887 kg |
| Hook skid | 2,162 kg | 2,162 kg |
| **Station, empty** | | **≈ 6.2 t** |

## Notes for the fabricator

1. **Bends.** DXF flats are outside-dimension nets. Apply your own bend deductions and corner reliefs.
2. **Deck plate.** At 6,300 × 2,450 it is over standard plate size. Join it over a cross member with a full-penetration butt weld.
3. **Lid.** It slopes 100 over 1,140 (5°), so the drip edge bends down about 85° to vertical. The copper ridge is a painted stripe, so nothing rises above 2,000.
4. **Materials and welding.**
   - Plate: Gr 250/300.
   - Hollow sections: C350L0 to AS/NZS 1163.
   - Welding: AS/NZS 1554.1 SP. Kerb rail welds are continuous.
5. **Hidden members.** The base runners (RHS 75 × 50 × 4 inside each side wall) and the door stiffeners (RHS 50 × 25 × 3, on the inside face within the opening) are in the CAD and the cut list.
6. **Wall stiffening.** Propose any extra stiffening you think 4 mm walls need when full. Keep the inside faces smooth so loads slide out of the trap door.

## To confirm before cutting

- **Hook-lift fleet:** runner spacing (±550 shown), hook height (1,450 shown), roller size, and whether a 99 deck suits their trucks.
- **Engineering:** certification of the skid, hook, fork pockets, trap-door hinges and latches, and the rated load per bin.
- **One-module bins:** stability of the 565 wide bins on forks and when tipping.
- **Trap-door hardware:** hinge and latch hardware that stays inside the 10 mm buffer zone between bins.
- **Electrics:** lock, light, siren and controller hardware (by others), plus a 4G option for remote alarm alerts.
- **Finish:** paint system and corrosion protection.
- **Ridge capping:** whether to add a removable capping over the 60 mm ridge gap between the two rows.
